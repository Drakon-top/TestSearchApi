#!/bin/bash
# Запуск тестов каждые N минут.
#
# Вариант 1 — одной командой (все параметры аргументами):
#   ./run_every_10min.sh THREADS_COUNT REQUESTS_COUNT SEARCH_API_KEY SEARCH_API_FOLDERID [SSL_VERIFY] [INTERVAL_MINUTES]
#   Пример:
#   ./run_every_10min.sh 5 250 AQVNxxxx... b1g2abc... true 10
#
# Вариант 2 — параметры из окружения (export THREADS_COUNT=... и т.д.), затем:
#   ./run_every_10min.sh

usage() {
    echo "Usage: $0 [THREADS_COUNT REQUESTS_COUNT SEARCH_API_KEY SEARCH_API_FOLDERID [SSL_VERIFY] [INTERVAL_MINUTES]]"
    echo "  Or set env: THREADS_COUNT, REQUESTS_COUNT, SEARCH_API_KEY, SEARCH_API_FOLDERID and run $0"
    echo "  INTERVAL_MINUTES defaults to 10, SSL_VERIFY to true."
}

if [ "$1" = "-h" ] || [ "$1" = "--help" ]; then
    usage
    exit 0
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

if [ -n "$4" ]; then
    export THREADS_COUNT="$1"
    export REQUESTS_COUNT="$2"
    export SEARCH_API_KEY="$3"
    export SEARCH_API_FOLDERID="$4"
    export SSL_VERIFY="${5:-true}"
    export INTERVAL_MINUTES="${6:-10}"
fi

INTERVAL_MINUTES="${INTERVAL_MINUTES:-10}"
INTERVAL_SECONDS=$((INTERVAL_MINUTES * 60))

if [ -z "$THREADS_COUNT" ] || [ -z "$REQUESTS_COUNT" ] || [ -z "$SEARCH_API_KEY" ] || [ -z "$SEARCH_API_FOLDERID" ]; then
    echo "Error: set THREADS_COUNT, REQUESTS_COUNT, SEARCH_API_KEY, SEARCH_API_FOLDERID (env or arguments)."
    usage
    exit 1
fi

echo "Tests will run every ${INTERVAL_MINUTES} minute(s). Press Ctrl+C to stop."
echo ""

while true; do
    echo "=== Run at $(date '+%Y-%m-%d %H:%M:%S') ==="
    if bash run_all.sh; then
        echo "Run finished successfully."
    else
        echo "Run finished with errors (continuing anyway)."
    fi
    echo "Next run in ${INTERVAL_MINUTES} minute(s)."
    sleep "$INTERVAL_SECONDS"
done
