#!/bin/bash

if [ ! -d venv ]; then
    python3 -m venv venv
fi

source venv/bin/activate
pip3 install -q -r requirements.txt

# SSL verification: можно установить через переменную окружения SSL_VERIFY (true/false)
# По умолчанию SSL проверка включена (true)
SSL_VERIFY=${SSL_VERIFY:-true}

python3 main.py --threads-count $THREADS_COUNT --requests-count $REQUESTS_COUNT --action v2 --groups-on-page 50 --lang en --ssl-verify $SSL_VERIFY --output report_rest_top_50_lang_en.csv
python3 main.py --threads-count $THREADS_COUNT --requests-count $REQUESTS_COUNT --action grpc_default --groups-on-page 50 --lang en --ssl-verify $SSL_VERIFY --output report_grpc_default_top_50_lang_en.csv