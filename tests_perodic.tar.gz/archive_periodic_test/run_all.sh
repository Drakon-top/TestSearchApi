#!/bin/bash
# Периодический запуск тестов каждые 5 минут (gRPC + REST), результаты в CSV.
# Использование: SEARCH_API_KEY=... SEARCH_API_FOLDERID=... [THREADS_COUNT=4] [REQUESTS_COUNT=50] ./run_all.sh

set -e

export PIP_ROOT_USER_ACTION=ignore

PYTHON_CMD="python3"
[ -n "$(command -v python3.10 2>/dev/null)" ] && PYTHON_CMD="python3.10"

if [ ! -d venv ]; then
    $PYTHON_CMD -m venv venv
fi
source venv/bin/activate

pip install -q -r requirements.txt

# Интервал между прогонами (секунды). По умолчанию 300 (5 минут).
INTERVAL=${INTERVAL:-300}
THREADS_COUNT=${THREADS_COUNT:-4}
REQUESTS_COUNT=${REQUESTS_COUNT:-50}

$PYTHON_CMD run_periodic_tests.py \
  --interval "$INTERVAL" \
  --threads-count "$THREADS_COUNT" \
  --requests-count "$REQUESTS_COUNT" \
  --output periodic_test_results.csv
