# Нагрузочное тестирование Search API (gRPC + REST)

Периодический запуск тестов к Yandex Cloud Search API: каждые 5 минут выполняются прогоны по gRPC и REST, метрики записываются в CSV для построения графиков.

## Что нужно

- Python 3.8+
- Переменные окружения: `SEARCH_API_KEY`, `SEARCH_API_FOLDERID`

## One-line запуск

```bash
SEARCH_API_KEY="ваш-ключ" SEARCH_API_FOLDERID="ваш-folder-id" ./run_all.sh
```

Скрипт сам создаст venv (если нет), установит зависимости и запустит периодические тесты (интервал 5 минут). Результаты — в `periodic_test_results.csv`.

## Опциональные переменные

- `THREADS_COUNT=4` — число параллельных потоков
- `REQUESTS_COUNT=50` — запросов за один прогон
- `INTERVAL=300` — интервал между прогонами в секундах (по умолчанию 300)

Пример:

```bash
SEARCH_API_KEY="..." SEARCH_API_FOLDERID="..." THREADS_COUNT=8 REQUESTS_COUNT=100 ./run_all.sh
```

## Файлы

- `run_all.sh` — точка входа: venv, зависимости, запуск периодических тестов
- `run_periodic_tests.py` — цикл каждые N секунд, прогоны gRPC и REST, запись в CSV
- `main.py` — ядро нагрузочного теста (используется из `run_periodic_tests.py`)
- `queries.jsonl` — список запросов (если нет — генерируются автоматически)
- `periodic_test_results.csv` — выходной CSV (дата, время, P95/P99 latency, пустые/плохие запросы, всего запросов)
