#!/usr/bin/env python3
"""
Скрипт запускает нагрузочные тесты каждые 5 минут (gRPC и REST),
собирает метрики и записывает их в CSV, удобный для построения графиков.

Использование:
  export SEARCH_API_KEY=... SEARCH_API_FOLDERID=...
  python run_periodic_tests.py [--interval 300] [--output results.csv]

Формат CSV: дата, время, P95/P99 latency (gprs, rest), пустые/плохие запросы, всего запросов.
"""

import argparse
import asyncio
import csv
import datetime
import logging
import os
import sys

# импортируем модуль под другим именем, чтобы не затенять локальную функцию main()
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import main as main_module

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger(__name__)


# Настройки по умолчанию (можно переопределить переменными окружения)
DEFAULT_QUERIES_FILE = os.environ.get("QUERIES_FILE", "queries.jsonl")
DEFAULT_THREADS_COUNT = int(os.environ.get("THREADS_COUNT", "4"))
DEFAULT_REQUESTS_COUNT = int(os.environ.get("REQUESTS_COUNT", "50"))
DEFAULT_GROUPS_ON_PAGE = int(os.environ.get("GROUPS_ON_PAGE", "50"))
DEFAULT_LANG = os.environ.get("LANG", "en")
DEFAULT_INTERVAL_SEC = 300  # 5 минут
DEFAULT_OUTPUT_CSV = "periodic_test_results.csv"

# Типы тестов: gRPC и REST
ACTION_GRPC = "grpc_default"
ACTION_REST = "v2"


def get_args():
    p = argparse.ArgumentParser(description="Периодический запуск тестов gRPC и REST с записью метрик в CSV")
    p.add_argument("--interval", type=int, default=DEFAULT_INTERVAL_SEC, help="Интервал между прогонами в секундах (по умолчанию 300)")
    p.add_argument("--output", type=str, default=DEFAULT_OUTPUT_CSV, help="Файл CSV с результатами")
    p.add_argument("--queries-file", type=str, default=DEFAULT_QUERIES_FILE)
    p.add_argument("--threads-count", type=int, default=DEFAULT_THREADS_COUNT)
    p.add_argument("--requests-count", type=int, default=DEFAULT_REQUESTS_COUNT)
    p.add_argument("--groups-on-page", type=int, default=DEFAULT_GROUPS_ON_PAGE)
    p.add_argument("--lang", type=str, default=DEFAULT_LANG)
    p.add_argument("--once", action="store_true", help="Выполнить один прогон и выйти (без цикла)")
    return p.parse_args()


def ensure_csv_header(filepath: str):
    """Создать файл с заголовками, если его ещё нет."""
    if os.path.exists(filepath):
        return
    headers = [
        "date",
        "time",
        "timestamp_iso",
        "p95_latency_gprs_ms",
        "p99_latency_gprs_ms",
        "p95_latency_rest_ms",
        "p99_latency_rest_ms",
        "empty_and_bad_gprs",
        "empty_gprs",
        "bad_gprs",
        "total_requests_gprs",
        "empty_and_bad_rest",
        "empty_rest",
        "bad_rest",
        "total_requests_rest",
    ]
    with open(filepath, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(headers)
    logger.info("Создан файл результатов: %s", filepath)


def append_result_row(filepath: str, row: list):
    with open(filepath, "a", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(row)


async def run_one_cycle(
    output_csv: str,
    queries_file: str,
    threads_count: int,
    requests_count: int,
    groups_on_page: int,
    lang: str,
) -> bool:
    """Один цикл: тест gRPC, тест REST, запись одной строки в CSV. Возвращает True при успехе."""
    now = datetime.datetime.now()
    date_str = now.strftime("%Y-%m-%d")
    time_str = now.strftime("%H:%M:%S")
    ts_iso = now.isoformat()

    common = {
        "queries_file": queries_file,
        "threads_count": threads_count,
        "requests_count": requests_count,
        "groups_on_page": groups_on_page,
        "lang": lang or None,
        "full_texts": False,
        "no_reuse_ssl": False,
        "ssl_verify": os.environ.get("SSL_VERIFY", "true").lower() in ("true", "1", "yes", "on"),
    }

    try:
        logger.info("Запуск теста gRPC (%s)...", ACTION_GRPC)
        traces_gprs = await main_module.run_load(action=ACTION_GRPC, **common)
        stats_gprs = main_module.compute_stats(traces_gprs)
        logger.info("gRPC: total=%s, p95=%s ms, p99=%s ms, empty_and_bad=%s",
                    stats_gprs["total_requests"], stats_gprs["p95_latency_ms"], stats_gprs["p99_latency_ms"],
                    stats_gprs["empty_and_bad"])

        logger.info("Запуск теста REST (%s)...", ACTION_REST)
        traces_rest = await main_module.run_load(action=ACTION_REST, **common)
        stats_rest = main_module.compute_stats(traces_rest)
        logger.info("REST: total=%s, p95=%s ms, p99=%s ms, empty_and_bad=%s",
                    stats_rest["total_requests"], stats_rest["p95_latency_ms"], stats_rest["p99_latency_ms"],
                    stats_rest["empty_and_bad"])
    except Exception as e:
        logger.exception("Ошибка в прогоне: %s", e)
        # Записываем строку с ошибкой (пустые/нулевые метрики для неудачного прогона)
        row = [
            date_str, time_str, ts_iso,
            0, 0, 0, 0,
            0, 0, 0, 0,
            0, 0, 0, 0,
        ]
        append_result_row(output_csv, row)
        return False

    row = [
        date_str,
        time_str,
        ts_iso,
        stats_gprs["p95_latency_ms"],
        stats_gprs["p99_latency_ms"],
        stats_rest["p95_latency_ms"],
        stats_rest["p99_latency_ms"],
        stats_gprs["empty_and_bad"],
        stats_gprs["empty_results"],
        stats_gprs["bad_responses"],
        stats_gprs["total_requests"],
        stats_rest["empty_and_bad"],
        stats_rest["empty_results"],
        stats_rest["bad_responses"],
        stats_rest["total_requests"],
    ]
    append_result_row(output_csv, row)
    logger.info("Результаты записаны в %s", output_csv)
    return True


async def main_async(args):
    if not os.environ.get("SEARCH_API_KEY") or not os.environ.get("SEARCH_API_FOLDERID"):
        logger.error("Нужны переменные окружения: SEARCH_API_KEY, SEARCH_API_FOLDERID")
        sys.exit(1)

    ensure_csv_header(args.output)

    if args.once:
        await run_one_cycle(
            output_csv=args.output,
            queries_file=args.queries_file,
            threads_count=args.threads_count,
            requests_count=args.requests_count,
            groups_on_page=args.groups_on_page,
            lang=args.lang,
        )
        return

    while True:
        await run_one_cycle(
            output_csv=args.output,
            queries_file=args.queries_file,
            threads_count=args.threads_count,
            requests_count=args.requests_count,
            groups_on_page=args.groups_on_page,
            lang=args.lang,
        )
        logger.info("Следующий прогон через %s с.", args.interval)
        await asyncio.sleep(args.interval)


def main():
    args = get_args()
    asyncio.run(main_async(args))


if __name__ == "__main__":
    main()
